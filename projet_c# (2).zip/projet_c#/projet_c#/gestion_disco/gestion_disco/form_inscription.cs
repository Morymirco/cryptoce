﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Data;

namespace gestion_disco
{
    public partial class form_inscription : Form
    {
        public form_inscription()
        {
            InitializeComponent();
        }

        private void btn_inscrire_Click(object sender, EventArgs e)
        {
            string login = login_txt.Text;
            string password = txt_pwd.Text;
            DateTime dateDeCreation = DateTime.Now; // La date actuelle de création

            // Vérifier que tous les champs sont remplis correctement
            if (string.IsNullOrWhiteSpace(login) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Veuillez remplir tous les champs correctement.");
                return;
            }

            // Connexion à la base de données
            using (SqlConnection connection = new SqlConnection("Data Source=(local);Initial Catalog=DiscoDB;Persist Security Info=True;User ID=dluganc;Password=DL@2025"))
            {
                connection.Open();
                string query = "INSERT INTO Utilisateurs (login, password, date_creation) VALUES (@login, @password, @date_creation)";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Ajout des paramètres à la requête SQL
                    command.Parameters.AddWithValue("@login", login);
                    command.Parameters.AddWithValue("@password", password);
                    command.Parameters.AddWithValue("@date_creation", dateDeCreation);

                    try
                    {
                        // Exécuter la commande
                        command.ExecuteNonQuery();
                        MessageBox.Show("Utilisateur inscrit avec succès !");
                        ClearFields(); // Effacer les champs après l'inscription
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Erreur lors de l'inscription : " + ex.Message);
                    }
                }
            }
        }

        private void ClearFields()
        {
            login_txt.Clear();
            txt_pwd.Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Vous pouvez ajouter ici la logique pour quitter ou fermer le formulaire si nécessaire
            this.Close();
        }

       
    }
}
