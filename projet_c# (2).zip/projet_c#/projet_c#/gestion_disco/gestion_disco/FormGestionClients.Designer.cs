﻿namespace gestion_disco
{
    partial class FormGestionClients
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.TextBox txtNom;
        private System.Windows.Forms.TextBox txtPrenoms;
        private System.Windows.Forms.TextBox txtAdresse;
        private System.Windows.Forms.ComboBox cmbPlans;
        private System.Windows.Forms.Button btnAjouterClient;
        private System.Windows.Forms.DataGridView dataGridViewClients;
        private System.Windows.Forms.Label labelNom;
        private System.Windows.Forms.Label labelPrenoms;
        private System.Windows.Forms.Label labelAdresse;
        private System.Windows.Forms.Label labelPlan;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.txtNom = new System.Windows.Forms.TextBox();
            this.txtPrenoms = new System.Windows.Forms.TextBox();
            this.txtAdresse = new System.Windows.Forms.TextBox();
            this.cmbPlans = new System.Windows.Forms.ComboBox();
            this.btnAjouterClient = new System.Windows.Forms.Button();
            this.dataGridViewClients = new System.Windows.Forms.DataGridView();
            this.labelNom = new System.Windows.Forms.Label();
            this.labelPrenoms = new System.Windows.Forms.Label();
            this.labelAdresse = new System.Windows.Forms.Label();
            this.labelPlan = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewClients)).BeginInit();
            this.SuspendLayout();
            // 
            // txtNom
            // 
            this.txtNom.Location = new System.Drawing.Point(120, 30);
            this.txtNom.Name = "txtNom";
            this.txtNom.Size = new System.Drawing.Size(200, 26);
            this.txtNom.TabIndex = 9;
            // 
            // txtPrenoms
            // 
            this.txtPrenoms.Location = new System.Drawing.Point(120, 70);
            this.txtPrenoms.Name = "txtPrenoms";
            this.txtPrenoms.Size = new System.Drawing.Size(200, 26);
            this.txtPrenoms.TabIndex = 8;
            // 
            // txtAdresse
            // 
            this.txtAdresse.Location = new System.Drawing.Point(120, 110);
            this.txtAdresse.Name = "txtAdresse";
            this.txtAdresse.Size = new System.Drawing.Size(200, 26);
            this.txtAdresse.TabIndex = 7;
            // 
            // cmbPlans
            // 
            this.cmbPlans.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPlans.Location = new System.Drawing.Point(120, 150);
            this.cmbPlans.Name = "cmbPlans";
            this.cmbPlans.Size = new System.Drawing.Size(200, 28);
            this.cmbPlans.TabIndex = 6;
            this.cmbPlans.SelectedIndexChanged += new System.EventHandler(this.cmbPlans_SelectedIndexChanged);
            // 
            // btnAjouterClient
            // 
            this.btnAjouterClient.Location = new System.Drawing.Point(120, 190);
            this.btnAjouterClient.Name = "btnAjouterClient";
            this.btnAjouterClient.Size = new System.Drawing.Size(75, 23);
            this.btnAjouterClient.TabIndex = 5;
            this.btnAjouterClient.Text = "Ajouter";
            this.btnAjouterClient.UseVisualStyleBackColor = true;
            this.btnAjouterClient.Click += new System.EventHandler(this.btnAjouterClient_Click);
            // 
            // dataGridViewClients
            // 
            this.dataGridViewClients.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewClients.Location = new System.Drawing.Point(12, 230);
            this.dataGridViewClients.Name = "dataGridViewClients";
            this.dataGridViewClients.Size = new System.Drawing.Size(776, 300);
            this.dataGridViewClients.TabIndex = 4;
            // 
            // labelNom
            // 
            this.labelNom.AutoSize = true;
            this.labelNom.Location = new System.Drawing.Point(30, 33);
            this.labelNom.Name = "labelNom";
            this.labelNom.Size = new System.Drawing.Size(50, 20);
            this.labelNom.TabIndex = 3;
            this.labelNom.Text = "Nom :";
            // 
            // labelPrenoms
            // 
            this.labelPrenoms.AutoSize = true;
            this.labelPrenoms.Location = new System.Drawing.Point(30, 73);
            this.labelPrenoms.Name = "labelPrenoms";
            this.labelPrenoms.Size = new System.Drawing.Size(80, 20);
            this.labelPrenoms.TabIndex = 2;
            this.labelPrenoms.Text = "Prénoms :";
            // 
            // labelAdresse
            // 
            this.labelAdresse.AutoSize = true;
            this.labelAdresse.Location = new System.Drawing.Point(30, 113);
            this.labelAdresse.Name = "labelAdresse";
            this.labelAdresse.Size = new System.Drawing.Size(76, 20);
            this.labelAdresse.TabIndex = 1;
            this.labelAdresse.Text = "Adresse :";
            // 
            // labelPlan
            // 
            this.labelPlan.AutoSize = true;
            this.labelPlan.Location = new System.Drawing.Point(30, 153);
            this.labelPlan.Name = "labelPlan";
            this.labelPlan.Size = new System.Drawing.Size(48, 20);
            this.labelPlan.TabIndex = 0;
            this.labelPlan.Text = "Plan :";
            // 
            // FormGestionClients
            // 
            this.ClientSize = new System.Drawing.Size(800, 550);
            this.Controls.Add(this.labelPlan);
            this.Controls.Add(this.labelAdresse);
            this.Controls.Add(this.labelPrenoms);
            this.Controls.Add(this.labelNom);
            this.Controls.Add(this.dataGridViewClients);
            this.Controls.Add(this.btnAjouterClient);
            this.Controls.Add(this.cmbPlans);
            this.Controls.Add(this.txtAdresse);
            this.Controls.Add(this.txtPrenoms);
            this.Controls.Add(this.txtNom);
            this.Name = "FormGestionClients";
            this.Text = "Gestion des Clients";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewClients)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
    }
}