﻿namespace gestion_disco
{
    partial class form_inscription
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_login = new System.Windows.Forms.Label();
            this.lbl_pwd = new System.Windows.Forms.Label();
            this.lbl_role = new System.Windows.Forms.Label();
            this.login_txt = new System.Windows.Forms.TextBox();
            this.txt_pwd = new System.Windows.Forms.TextBox();
            this.btn_inscrire = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.btn_annuler = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_login
            // 
            this.lbl_login.AutoSize = true;
            this.lbl_login.Location = new System.Drawing.Point(57, 68);
            this.lbl_login.Name = "lbl_login";
            this.lbl_login.Size = new System.Drawing.Size(42, 20);
            this.lbl_login.TabIndex = 0;
            this.lbl_login.Text = "login";
            // 
            // lbl_pwd
            // 
            this.lbl_pwd.AutoSize = true;
            this.lbl_pwd.Location = new System.Drawing.Point(57, 148);
            this.lbl_pwd.Name = "lbl_pwd";
            this.lbl_pwd.Size = new System.Drawing.Size(77, 20);
            this.lbl_pwd.TabIndex = 1;
            this.lbl_pwd.Text = "password";
            // 
            // lbl_role
            // 
            this.lbl_role.AutoSize = true;
            this.lbl_role.Location = new System.Drawing.Point(57, 226);
            this.lbl_role.Name = "lbl_role";
            this.lbl_role.Size = new System.Drawing.Size(44, 20);
            this.lbl_role.TabIndex = 2;
            this.lbl_role.Text = "Date";
            // 
            // login_txt
            // 
            this.login_txt.Location = new System.Drawing.Point(235, 68);
            this.login_txt.Name = "login_txt";
            this.login_txt.Size = new System.Drawing.Size(144, 26);
            this.login_txt.TabIndex = 3;
            // 
            // txt_pwd
            // 
            this.txt_pwd.Location = new System.Drawing.Point(235, 145);
            this.txt_pwd.Name = "txt_pwd";
            this.txt_pwd.Size = new System.Drawing.Size(144, 26);
            this.txt_pwd.TabIndex = 4;
            // 
            // btn_inscrire
            // 
            this.btn_inscrire.Location = new System.Drawing.Point(61, 352);
            this.btn_inscrire.Name = "btn_inscrire";
            this.btn_inscrire.Size = new System.Drawing.Size(127, 32);
            this.btn_inscrire.TabIndex = 6;
            this.btn_inscrire.Text = "inscrire";
            this.btn_inscrire.UseVisualStyleBackColor = true;
            this.btn_inscrire.Click += new System.EventHandler(this.btn_inscrire_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(235, 226);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 26);
            this.dateTimePicker1.TabIndex = 7;
            // 
            // btn_annuler
            // 
            this.btn_annuler.Location = new System.Drawing.Point(258, 352);
            this.btn_annuler.Name = "btn_annuler";
            this.btn_annuler.Size = new System.Drawing.Size(126, 32);
            this.btn_annuler.TabIndex = 8;
            this.btn_annuler.Text = "Annuler";
            this.btn_annuler.UseVisualStyleBackColor = true;
            this.btn_annuler.Click += new System.EventHandler(this.button1_Click);
            // 
            // form_inscription
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(841, 625);
            this.Controls.Add(this.btn_annuler);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.btn_inscrire);
            this.Controls.Add(this.txt_pwd);
            this.Controls.Add(this.login_txt);
            this.Controls.Add(this.lbl_role);
            this.Controls.Add(this.lbl_pwd);
            this.Controls.Add(this.lbl_login);
            this.Name = "form_inscription";
            this.Text = "form_inscription";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_login;
        private System.Windows.Forms.Label lbl_pwd;
        private System.Windows.Forms.Label lbl_role;
        private System.Windows.Forms.TextBox login_txt;
        private System.Windows.Forms.TextBox txt_pwd;
        private System.Windows.Forms.Button btn_inscrire;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button btn_annuler;
    }
}