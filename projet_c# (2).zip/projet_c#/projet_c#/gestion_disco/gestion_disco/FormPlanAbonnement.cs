﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace gestion_disco
{
    public partial class FormPlanAbonnement : Form
    {
        public FormPlanAbonnement()
        {
            InitializeComponent();
            LoadPlans(); // Charger les plans d'abonnement existants
        }

        private void btnAjouterPlan_Click(object sender, EventArgs e)
        {
            int nombreDVD;
            decimal prixMensuel;

            if (!int.TryParse(txtNombreDVD.Text, out nombreDVD) || !decimal.TryParse(txtPrixMensuel.Text, out prixMensuel))
            {
                MessageBox.Show("Veuillez remplir tous les champs correctement.");
                return;
            }

            using (SqlConnection connection = new SqlConnection("Data Source=(local);Initial Catalog=DiscoDB;Persist Security Info=True;User ID=dluganc;Password=DL@2025"))
            {
                connection.Open();
                string query = "INSERT INTO Plans (nombre_dvd, prix_mensuel) VALUES (@nombreDVD, @prixMensuel)";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@nombreDVD", nombreDVD);
                    command.Parameters.AddWithValue("@prixMensuel", prixMensuel);

                    try
                    {
                        command.ExecuteNonQuery();
                        MessageBox.Show("Plan d'abonnement ajouté avec succès !");
                        ClearFields();
                        LoadPlans(); // Recharger les plans
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Erreur lors de l'ajout du plan : " + ex.Message);
                    }
                }
            }
        }

        private void ClearFields()
        {
            txtNombreDVD.Clear();
            txtPrixMensuel.Clear();
        }

        private void LoadPlans()
        {
            string connectionString = "Data Source=(local);Initial Catalog=DiscoDB;Persist Security Info=True;User ID=dluganc;Password=DL@2025";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT id_plan, nombre_dvd, prix_mensuel FROM Plans";
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                dataGridViewPlans.DataSource = dataTable; // Assurez-vous que dataGridViewPlans est défini dans le designer
            }
        }
    }
}