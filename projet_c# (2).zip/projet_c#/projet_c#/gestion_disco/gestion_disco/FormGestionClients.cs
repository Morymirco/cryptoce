﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace gestion_disco
{
    public partial class FormGestionClients : Form
    {
        public FormGestionClients()
        {
            InitializeComponent();
            LoadPlans(); // Charger les plans d'abonnement pour le ComboBox
            LoadClients(); // Charger les clients existants
        }

        private void btnAjouterClient_Click(object sender, EventArgs e)
        {
            string nom = txtNom.Text;
            string prenoms = txtPrenoms.Text;
            string adresse = txtAdresse.Text;
            int idPlan = (int)cmbPlans.SelectedValue; // Récupérer l'ID du plan sélectionné

            if (string.IsNullOrWhiteSpace(nom) || string.IsNullOrWhiteSpace(prenoms) || string.IsNullOrWhiteSpace(adresse))
            {
                MessageBox.Show("Veuillez remplir tous les champs correctement.");
                return;
            }

            using (SqlConnection connection = new SqlConnection("Data Source=(local);Initial Catalog=DiscoDB;Persist Security Info=True;User ID=dluganc;Password=DL@2025"))
            {
                connection.Open();
                string query = "INSERT INTO Clients (nom, prenoms, adresse, id_plan) VALUES (@nom, @prenoms, @adresse, @idPlan)";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@nom", nom);
                    command.Parameters.AddWithValue("@prenoms", prenoms);
                    command.Parameters.AddWithValue("@adresse", adresse);
                    command.Parameters.AddWithValue("@idPlan", idPlan);

                    try
                    {
                        command.ExecuteNonQuery();
                        MessageBox.Show("Client ajouté avec succès !");
                        ClearFields();
                        LoadClients(); // Recharger les clients
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Erreur lors de l'ajout du client : " + ex.Message);
                    }
                }
            }
        }

        private void ClearFields()
        {
            txtNom.Clear();
            txtPrenoms.Clear();
            txtAdresse.Clear();
            cmbPlans.SelectedIndex = -1; // Réinitialiser le ComboBox
        }

        private void LoadClients()
        {
            string connectionString = "Data Source=(local);Initial Catalog=DiscoDB;Persist Security Info=True;User ID=dluganc;Password=DL@2025";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT id_client, nom, prenoms, adresse FROM Clients";
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                dataGridViewClients.DataSource = dataTable; // Assurez-vous que dataGridViewClients est défini dans le designer
            }
        }

        private void LoadPlans()
        {
            string connectionString ="Data Source=(local);Initial Catalog=DiscoDB;Persist Security Info=True;User ID=dluganc;Password=DL@2025";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT id_plan, nombre_dvd FROM Plans";
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                cmbPlans.DataSource = dataTable;
                cmbPlans.DisplayMember = "nombre_dvd"; // Afficher le nombre de DVD
                cmbPlans.ValueMember = "id_plan"; // Utiliser l'ID du plan comme valeur
            }
        }

        private void cmbPlans_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}