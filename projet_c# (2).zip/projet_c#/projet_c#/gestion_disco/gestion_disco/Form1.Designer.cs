﻿namespace gestion_disco
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.DataGridView dataGridViewDVD;
        private System.Windows.Forms.Button btnModifier;
        private System.Windows.Forms.Button btnSupprimer;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.txtCode = new System.Windows.Forms.TextBox();
            this.txtTitre = new System.Windows.Forms.TextBox();
            this.txtQuantite = new System.Windows.Forms.TextBox();
            this.btnAjouter = new System.Windows.Forms.Button();
            this.labelCode = new System.Windows.Forms.Label();
            this.labelTitre = new System.Windows.Forms.Label();
            this.labelQuantite = new System.Windows.Forms.Label();
            this.dataGridViewDVD = new System.Windows.Forms.DataGridView();
            this.btnModifier = new System.Windows.Forms.Button();
            this.btnSupprimer = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtCode
            // 
            this.txtCode.Location = new System.Drawing.Point(120, 30);
            this.txtCode.Name = "txtCode";
            this.txtCode.Size = new System.Drawing.Size(200, 20);
            this.txtCode.TabIndex = 0;
            // 
            // txtTitre
            // 
            this.txtTitre.Location = new System.Drawing.Point(120, 70);
            this.txtTitre.Name = "txtTitre";
            this.txtTitre.Size = new System.Drawing.Size(200, 20);
            this.txtTitre.TabIndex = 1;
            // 
            // txtQuantite
            // 
            this.txtQuantite.Location = new System.Drawing.Point(120, 110);
            this.txtQuantite.Name = "txtQuantite";
            this.txtQuantite.Size = new System.Drawing.Size(200, 20);
            this.txtQuantite.TabIndex = 2;
            // 
            // btnAjouter
            // 
            this.btnAjouter.Location = new System.Drawing.Point(120, 150);
            this.btnAjouter.Name = "btnAjouter";
            this.btnAjouter.Size = new System.Drawing.Size(75, 23);
            this.btnAjouter.TabIndex = 3;
            this.btnAjouter.Text = "Ajouter";
            this.btnAjouter.UseVisualStyleBackColor = true;
            this.btnAjouter.Click += new System.EventHandler(this.btnAjouter_Click);
            // 
            // labelCode
            // 
            this.labelCode.AutoSize = true;
            this.labelCode.Location = new System.Drawing.Point(30, 33);
            this.labelCode.Name = "labelCode";
            this.labelCode.Size = new System.Drawing.Size(34, 13);
            this.labelCode.TabIndex = 4;
            this.labelCode.Text = "Code:";
            // 
            // labelTitre
            // 
            this.labelTitre.AutoSize = true;
            this.labelTitre.Location = new System.Drawing.Point(30, 73);
            this.labelTitre.Name = "labelTitre";
            this.labelTitre.Size = new System.Drawing.Size(34, 13);
            this.labelTitre.TabIndex = 5;
            this.labelTitre.Text = "Titre:";
            // 
            // labelQuantite
            // 
            this.labelQuantite.AutoSize = true;
            this.labelQuantite.Location = new System.Drawing.Point(30, 113);
            this.labelQuantite.Name = "labelQuantite";
            this.labelQuantite.Size = new System.Drawing.Size(52, 13);
            this.labelQuantite.TabIndex = 6;
            this.labelQuantite.Text = "Quantité:";
            // 
            // dataGridViewDVD
            // 
            this.dataGridViewDVD.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDVD.Location = new System.Drawing.Point(12, 200);
            this.dataGridViewDVD.Name = "dataGridViewDVD";
            this.dataGridViewDVD.Size = new System.Drawing.Size(776, 300);
            this.dataGridViewDVD.TabIndex = 7;
            // 
            // btnModifier
            // 
            this.btnModifier.Location = new System.Drawing.Point(200, 150);
            this.btnModifier.Name = "btnModifier";
            this.btnModifier.Size = new System.Drawing.Size(75, 23);
            this.btnModifier.TabIndex = 8;
            this.btnModifier.Text = "Modifier";
            this.btnModifier.UseVisualStyleBackColor = true;
            this.btnModifier.Click += new System.EventHandler(this.btnModifier_Click);
            // 
            // btnSupprimer
            // 
            this.btnSupprimer.Location = new System.Drawing.Point(280, 150);
            this.btnSupprimer.Name = "btnSupprimer";
            this.btnSupprimer.Size = new System.Drawing.Size(75, 23);
            this.btnSupprimer.TabIndex = 9;
            this.btnSupprimer.Text = "Supprimer";
            this.btnSupprimer.UseVisualStyleBackColor = true;
            this.btnSupprimer.Click += new System.EventHandler(this.btnSupprimer_Click);
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(800, 550);
            this.Controls.Add(this.dataGridViewDVD);
            this.Controls.Add(this.labelQuantite);
            this.Controls.Add(this.labelTitre);
            this.Controls.Add(this.labelCode);
            this.Controls.Add(this.btnAjouter);
            this.Controls.Add(this.txtQuantite);
            this.Controls.Add(this.txtTitre);
            this.Controls.Add(this.txtCode);
            this.Controls.Add(this.btnModifier);
            this.Controls.Add(this.btnSupprimer);
            this.Name = "Form1";
            this.Text = "Gestion des DVD";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.TextBox txtCode;
        private System.Windows.Forms.TextBox txtTitre;
        private System.Windows.Forms.TextBox txtQuantite;
        private System.Windows.Forms.Button btnAjouter;
        private System.Windows.Forms.Label labelCode;
        private System.Windows.Forms.Label labelTitre;
        private System.Windows.Forms.Label labelQuantite;
    }
}