﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace gestion_disco
{
    public partial class FormConnexion : Form
    {
        public FormConnexion()
        {
            InitializeComponent();
        }

        private void btnConnexion_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Veuillez entrer un nom d'utilisateur et un mot de passe.");
                return;
            }

            // Connexion à la base de données pour vérifier les identifiants
            using (SqlConnection connection = new SqlConnection("Data Source=(local);Initial Catalog=DiscoDB;Persist Security Info=True;User ID=dluganc;Password=DL@2025"))
            {
                connection.Open();
                string query = "SELECT COUNT(*) FROM Utilisateurs WHERE login = @login AND password = @password";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Ajouter les paramètres de la requête
                    command.Parameters.AddWithValue("@login", username);
                    command.Parameters.AddWithValue("@password", password);

                    try
                    {
                        int userCount = (int)command.ExecuteScalar();
                        if (userCount > 0)
                        {
                            // Si l'utilisateur existe, ouvrir le formulaire suivant
                            FormBienvenue formBienvenue = new FormBienvenue();
                            formBienvenue.Show();
                            this.Hide(); // Masquer le formulaire de connexion
                        }
                        else
                        {
                            MessageBox.Show("Nom d'utilisateur ou mot de passe incorrect.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Erreur lors de l'authentification : " + ex.Message);
                    }
                }
            }
        }
    }
}
