﻿namespace gestion_disco
{
    partial class FormBienvenue
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Button btnGestionDVD;
        private System.Windows.Forms.Button btnGestionPlans;
        private System.Windows.Forms.Label labelBienvenue;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.btnGestionDVD = new System.Windows.Forms.Button();
            this.btnGestionPlans = new System.Windows.Forms.Button();
            this.labelBienvenue = new System.Windows.Forms.Label();
            this.btn_listeUser = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnGestionDVD
            // 
            this.btnGestionDVD.Location = new System.Drawing.Point(100, 100);
            this.btnGestionDVD.Name = "btnGestionDVD";
            this.btnGestionDVD.Size = new System.Drawing.Size(200, 50);
            this.btnGestionDVD.TabIndex = 2;
            this.btnGestionDVD.Text = "Gestion des DVD";
            this.btnGestionDVD.UseVisualStyleBackColor = true;
            this.btnGestionDVD.Click += new System.EventHandler(this.btnGestionDVD_Click);
            // 
            // btnGestionPlans
            // 
            this.btnGestionPlans.Location = new System.Drawing.Point(100, 160);
            this.btnGestionPlans.Name = "btnGestionPlans";
            this.btnGestionPlans.Size = new System.Drawing.Size(200, 50);
            this.btnGestionPlans.TabIndex = 1;
            this.btnGestionPlans.Text = "Gestion des Plans";
            this.btnGestionPlans.UseVisualStyleBackColor = true;
            this.btnGestionPlans.Click += new System.EventHandler(this.btnGestionPlans_Click);
            // 
            // labelBienvenue
            // 
            this.labelBienvenue.AutoSize = true;
            this.labelBienvenue.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.labelBienvenue.Location = new System.Drawing.Point(95, 30);
            this.labelBienvenue.Name = "labelBienvenue";
            this.labelBienvenue.Size = new System.Drawing.Size(393, 32);
            this.labelBienvenue.TabIndex = 0;
            this.labelBienvenue.Text = "Bienvenue dans l\'application !";
            // 
            // btn_listeUser
            // 
            this.btn_listeUser.Location = new System.Drawing.Point(100, 238);
            this.btn_listeUser.Name = "btn_listeUser";
            this.btn_listeUser.Size = new System.Drawing.Size(200, 50);
            this.btn_listeUser.TabIndex = 3;
            this.btn_listeUser.Text = "Liste des Utilisateurs";
            this.btn_listeUser.UseVisualStyleBackColor = true;
            this.btn_listeUser.Click += new System.EventHandler(this.button1_Click);
            // 
            // FormBienvenue
            // 
            this.ClientSize = new System.Drawing.Size(400, 300);
            this.Controls.Add(this.btn_listeUser);
            this.Controls.Add(this.labelBienvenue);
            this.Controls.Add(this.btnGestionPlans);
            this.Controls.Add(this.btnGestionDVD);
            this.Name = "FormBienvenue";
            this.Text = "Bienvenue";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private System.Windows.Forms.Button btn_listeUser;
    }
}