﻿using System;
using System.Windows.Forms;

namespace gestion_disco
{
    public partial class FormBienvenue : Form
    {
        public FormBienvenue()
        {
            InitializeComponent();
        }

        private void btnGestionDVD_Click(object sender, EventArgs e)
        {
            Form1 formDVD = new Form1();
            formDVD.Show();
            this.Hide(); // Masquer le formulaire de bienvenue
        }

        private void btnGestionPlans_Click(object sender, EventArgs e)
        {
            FormPlanAbonnement formPlans = new FormPlanAbonnement();
            formPlans.Show();
            this.Hide(); // Masquer le formulaire de bienvenue
        }

        private void button1_Click(object sender, EventArgs e)
        {
            form_inscription fUser = new form_inscription();
            fUser.Show();
            this.Hide();
        }
    }
}