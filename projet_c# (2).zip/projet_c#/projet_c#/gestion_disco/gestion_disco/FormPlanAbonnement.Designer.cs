﻿namespace gestion_disco
{
    partial class FormPlanAbonnement
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.TextBox txtNombreDVD;
        private System.Windows.Forms.TextBox txtPrixMensuel;
        private System.Windows.Forms.Button btnAjouterPlan;
        private System.Windows.Forms.DataGridView dataGridViewPlans;
        private System.Windows.Forms.Label labelNombreDVD;
        private System.Windows.Forms.Label labelPrixMensuel;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.txtNombreDVD = new System.Windows.Forms.TextBox();
            this.txtPrixMensuel = new System.Windows.Forms.TextBox();
            this.btnAjouterPlan = new System.Windows.Forms.Button();
            this.dataGridViewPlans = new System.Windows.Forms.DataGridView();
            this.labelNombreDVD = new System.Windows.Forms.Label();
            this.labelPrixMensuel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPlans)).BeginInit();
            this.SuspendLayout();
            // 
            // txtNombreDVD
            // 
            this.txtNombreDVD.Location = new System.Drawing.Point(120, 30);
            this.txtNombreDVD.Name = "txtNombreDVD";
            this.txtNombreDVD.Size = new System.Drawing.Size(200, 20);
            this.txtNombreDVD.TabIndex = 0;
            // 
            // txtPrixMensuel
            // 
            this.txtPrixMensuel.Location = new System.Drawing.Point(120, 70);
            this.txtPrixMensuel.Name = "txtPrixMensuel";
            this.txtPrixMensuel.Size = new System.Drawing.Size(200, 20);
            this.txtPrixMensuel.TabIndex = 1;
            // 
            // btnAjouterPlan
            // 
            this.btnAjouterPlan.Location = new System.Drawing.Point(120, 110);
            this.btnAjouterPlan.Name = "btnAjouterPlan";
            this.btnAjouterPlan.Size = new System.Drawing.Size(75, 23);
            this.btnAjouterPlan.TabIndex = 2;
            this.btnAjouterPlan.Text = "Ajouter";
            this.btnAjouterPlan.UseVisualStyleBackColor = true;
            this.btnAjouterPlan.Click += new System.EventHandler(this.btnAjouterPlan_Click);
            // 
            // dataGridViewPlans
            // 
            this.dataGridViewPlans.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewPlans.Location = new System.Drawing.Point(12, 150);
            this.dataGridViewPlans.Name = "dataGridViewPlans";
            this.dataGridViewPlans.Size = new System.Drawing.Size(776, 300);
            this.dataGridViewPlans.TabIndex = 3;
            // 
            // labelNombreDVD
            // 
            this.labelNombreDVD.AutoSize = true;
            this.labelNombreDVD.Location = new System.Drawing.Point(30, 33);
            this.labelNombreDVD.Name = "labelNombreDVD";
            this.labelNombreDVD.Size = new System.Drawing.Size(84, 13);
            this.labelNombreDVD.TabIndex = 4;
            this.labelNombreDVD.Text = "Nombre de DVD :";
            // 
            // labelPrixMensuel
            // 
            this.labelPrixMensuel.AutoSize = true;
            this.labelPrixMensuel.Location = new System.Drawing.Point(30, 73);
            this.labelPrixMensuel.Name = "labelPrixMensuel";
            this.labelPrixMensuel.Size = new System.Drawing.Size(76, 13);
            this.labelPrixMensuel.TabIndex = 5;
            this.labelPrixMensuel.Text = "Prix Mensuel :";
            // 
            // FormPlanAbonnement
            // 
            this.ClientSize = new System.Drawing.Size(800, 550);
            this.Controls.Add(this.labelPrixMensuel);
            this.Controls.Add(this.labelNombreDVD);
            this.Controls.Add(this.dataGridViewPlans);
            this.Controls.Add(this.btnAjouterPlan);
            this.Controls.Add(this.txtPrixMensuel);
            this.Controls.Add(this.txtNombreDVD);
            this.Name = "FormPlanAbonnement";
            this.Text = "Gestion des Plans d'Abonnement";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPlans)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}