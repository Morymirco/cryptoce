﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace gestion_disco
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            LoadDVDs(); // Charger les données lors de l'initialisation du formulaire
        }

        private void btnAjouter_Click(object sender, EventArgs e)
        {
            string code = txtCode.Text;
            string titre = txtTitre.Text;
            int quantiteDisponible;

            if (string.IsNullOrWhiteSpace(code) || string.IsNullOrWhiteSpace(titre) || !int.TryParse(txtQuantite.Text, out quantiteDisponible))
            {
                MessageBox.Show("Veuillez remplir tous les champs correctement.");
                return;
            }

            // Connexion à la base de données
            using (SqlConnection connection = new SqlConnection("Data Source=(local);Initial Catalog=DiscoDB;Persist Security Info=True;User ID=dluganc;Password=DL@2025"))
            {
                connection.Open();
                string query = "INSERT INTO DVD (code, titre, quantite_disponible) VALUES (@code, @titre, @quantite)";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@code", code);
                    command.Parameters.AddWithValue("@titre", titre);
                    command.Parameters.AddWithValue("@quantite", quantiteDisponible);

                    try
                    {
                        command.ExecuteNonQuery();
                        MessageBox.Show("DVD ajouté avec succès !");
                        ClearFields();
                        LoadDVDs(); // Recharger les données après l'ajout
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Erreur lors de l'ajout du DVD : " + ex.Message);
                    }
                }
            }
        }

        private void ClearFields()
        {
            txtCode.Clear();
            txtTitre.Clear();
            txtQuantite.Clear();
        }

        private void LoadDVDs()
        {
            string connectionString = "Data Source=(local);Initial Catalog=DiscoDB;Persist Security Info=True;User ID=dluganc;Password=DL@2025";// Remplacez par votre chaîne de connexion
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT id_dvd, code, titre, quantite_disponible FROM DVD";
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                dataGridViewDVD.DataSource = dataTable; // Assurez-vous que dataGridViewDVD est défini dans le designer
            }
        }

        private void btnModifier_Click(object sender, EventArgs e)
        {
            if (dataGridViewDVD.SelectedRows.Count > 0)
            {
                int idDVD = Convert.ToInt32(dataGridViewDVD.SelectedRows[0].Cells["id_dvd"].Value);
                string code = txtCode.Text;
                string titre = txtTitre.Text;
                int quantiteDisponible;

                if (string.IsNullOrWhiteSpace(code) || string.IsNullOrWhiteSpace(titre) || !int.TryParse(txtQuantite.Text, out quantiteDisponible))
                {
                    MessageBox.Show("Veuillez remplir tous les champs correctement.");
                    return;
                }

                using (SqlConnection connection = new SqlConnection("Data Source=(local);Initial Catalog=DiscoDB;Persist Security Info=True;User ID=dluganc;Password=DL@2025"))
                {
                    connection.Open();
                    string query = "UPDATE DVD SET code = @code, titre = @titre, quantite_disponible = @quantite WHERE id_dvd = @id";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@code", code);
                        command.Parameters.AddWithValue("@titre", titre);
                        command.Parameters.AddWithValue("@quantite", quantiteDisponible);
                        command.Parameters.AddWithValue("@id", idDVD);

                        try
                        {
                            command.ExecuteNonQuery();
                            MessageBox.Show("DVD modifié avec succès !");
                            LoadDVDs(); // Recharger les données après la modification
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Erreur lors de la modification du DVD : " + ex.Message);
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Veuillez sélectionner un DVD à modifier.");
            }
        }

        private void btnSupprimer_Click(object sender, EventArgs e)
        {
            if (dataGridViewDVD.SelectedRows.Count > 0)
            {
                int idDVD = Convert.ToInt32(dataGridViewDVD.SelectedRows[0].Cells["id_dvd"].Value);
                using (SqlConnection connection = new SqlConnection("Data Source=(local);Initial Catalog=DiscoDB;Persist Security Info=True;User ID=dluganc;Password=DL@2025"))
                {
                    connection.Open();
                    string query = "DELETE FROM DVD WHERE id_dvd = @id";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@id", idDVD);
                        try
                        {
                            command.ExecuteNonQuery();
                            MessageBox.Show("DVD supprimé avec succès !");
                            LoadDVDs(); // Recharger les données après la suppression
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Erreur lors de la suppression du DVD : " + ex.Message);
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Veuillez sélectionner un DVD à supprimer.");
            }
        }
    }
}