-- Création de la table des utilisateurs (pour l'authentification)
CREATE TABLE Utilisateurs (
    id_utilisateur INT IDENTITY(1,1) PRIMARY KEY,
    login VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    date_creation DATETIME DEFAULT GETDATE()
);

-- Création de la table des plans d'abonnement
CREATE TABLE Plans (
    id_plan INT IDENTITY(1,1) PRIMARY KEY,
    nombre_dvd INT NOT NULL,
    prix_mensuel DECIMAL(10,2) NOT NULL
);

-- Création de la table des clients
CREATE TABLE Clients (
    id_client INT IDENTITY(1,1) PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    prenoms VARCHAR(100) NOT NULL,
    adresse TEXT NOT NULL,
    id_plan INT FOREIGN KEY REFERENCES Plans(id_plan),
    date_inscription DATETIME DEFAULT GETDATE()
);

-- Création de la table des DVD
CREATE TABLE DVD (
    id_dvd INT IDENTITY(1,1) PRIMARY KEY,
    code VARCHAR(20) NOT NULL UNIQUE,
    titre VARCHAR(200) NOT NULL,
    quantite_disponible INT NOT NULL DEFAULT 0
);

-- Création de la table des mouvements (registre)
CREATE TABLE Mouvements (
    id_mouvement INT IDENTITY(1,1) PRIMARY KEY,
    id_client INT FOREIGN KEY REFERENCES Clients(id_client),
    id_dvd INT FOREIGN KEY REFERENCES DVD(id_dvd),
    type_mouvement CHAR(1) NOT NULL, -- 'R' pour retrait, 'D' pour dépôt
    date_mouvement DATETIME DEFAULT GETDATE()
);


CREATE TABLE Details_Mouvement (
    id_detail_mouvement INT IDENTITY(1,1) PRIMARY KEY,
    id_mouvement INT FOREIGN KEY REFERENCES Mouvements(id_mouvement),
    id_dvd INT FOREIGN KEY REFERENCES DVD(id_dvd),
    quantite INT NOT NULL DEFAULT 1
);