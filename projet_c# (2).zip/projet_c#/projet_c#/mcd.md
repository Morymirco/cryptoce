erDiagram
    UTILISATEURS {
        int id_utilisateur PK
        varchar(50) login
        varchar(255) password
        datetime date_creation
    }

    PLANS {
        int id_plan PK
        int nombre_dvd
        decimal prix_mensuel
    }

    CLIENTS {
        int id_client PK
        varchar(100) nom
        varchar(100) prenoms
        text adresse
        datetime date_inscription
    }

    DVD {
        int id_dvd PK
        varchar(20) code
        varchar(200) titre
        int quantite_disponible
    }

    MOUVEMENTS {
        int id_mouvement PK
        char type_mouvement
        datetime date_mouvement
    }

    CLIENTS ||--|| PLANS : "s'abonne à"
    MOUVEMENTS }o--|| CLIENTS : "concerne"
    MOUVEMENTS }o--|| DVD : "implique"



1. **UTILISATEURS** (entité indépendante)
2. **PLANS** (entité indépendante)
3. **CLIENTS** (entité indépendante)
4. **DVD** (entité indépendante)
5. **MOUVEMENTS** (entité indépendante)

Explications des relations :
UTILISATEURS (entité indépendante)
Gère l'authentification des employés de la boutique
Non relié aux autres entités car c'est pour la gestion interne
PLANS ← CLIENTS
Relation 1:N (Un plan peut avoir plusieurs clients, un client a un seul plan)
Définit le nombre de DVD autorisés et le prix mensuel
CLIENTS ← MOUVEMENTS
Relation 1:N (Un client peut avoir plusieurs mouvements)
Enregistre qui effectue le mouvement
DVD ← MOUVEMENTS
Relation 1:N (Un DVD peut avoir plusieurs mouvements)
Trace quel DVD est concerné par le mouvement
Cardinalités :
Un CLIENT s'abonne à un et un seul PLAN (1,1)
Un PLAN peut avoir zéro ou plusieurs CLIENTS (0,N)
Un MOUVEMENT concerne un et un seul CLIENT (1,1)
Un CLIENT peut avoir zéro ou plusieurs MOUVEMENTS (0,N)
Un MOUVEMENT implique un et un seul DVD (1,1)
Un DVD peut avoir zéro ou plusieurs MOUVEMENTS (0,N)
Contraintes particulières :
Le login dans UTILISATEURS est UNIQUE
Le code dans DVD est UNIQUE
type_mouvement dans MOUVEMENTS ne peut être que 'R' (Retrait) ou 'D' (Dépôt)
quantite_disponible dans DVD ne peut pas être négative
nombre_dvd dans PLANS doit être soit 4 soit 5 selon les règles métier
DVD ← MOUVEMENTS
Relation 1:N (Un DVD peut avoir plusieurs mouvements)
Trace quel DVD est concerné par le mouvement
Cardinalités :
Un CLIENT s'abonne à un et un seul PLAN (1,1)
Un PLAN peut avoir zéro ou plusieurs CLIENTS (0,N)
Un MOUVEMENT concerne un et un seul CLIENT (1,1)
Un CLIENT peut avoir zéro ou plusieurs MOUVEMENTS (0,N)
Un MOUVEMENT implique un et un seul DVD (1,1)
Un DVD peut avoir zéro ou plusieurs MOUVEMENTS (0,N)
Contraintes particulières :
Le login dans UTILISATEURS est UNIQUE
Le code dans DVD est UNIQUE
type_mouvement dans MOUVEMENTS ne peut être que 'R' (Retrait) ou 'D' (Dépôt)
quantite_disponible dans DVD ne peut pas être négative
nombre_dvd dans PLANS doit être soit 4 soit 5 selon les règles métier










Lors d'un retrait, il faut :
Vérifier si le client peut emprunter (selon son plan)
Vérifier si le DVD est disponible
Créer le mouvement
Mettre à jour le stock