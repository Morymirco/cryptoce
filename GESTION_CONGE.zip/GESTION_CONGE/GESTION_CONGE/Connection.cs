﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient; //Librairie d'accès à une base de données sous SQL serveurs
using System.Data; //librairie permettant d'etablir la chaine de connexion avec la BD  
using System.Windows.Forms; //....

namespace GESTION_CONGE
{
    class Connection
    {
        SqlConnection connex; //objet permettant d'ettablir la chaine de connexion avec la BD
        public SqlCommand cmd; //objet permettant de faire des transactions sql 
        public SqlDataReader dr; //objet permettant de parcourrir(lire) les enregistrement ligne par ligne

        public void connector()
        {
            connex.ConnectionString = "Data Source=(local);Initial Catalog=GESTION_CONGE;Integrated Security=True";
            try
            {
                if (connex.State == ConnectionState.Closed)
                {
                    connex.Open();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public SqlConnection initiliaserConnexion()
        {
            return connex;
        }
    }
}
