﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GESTION_CONGE
{
    class Auth
    {
        string nom;
        string pass;
        Form_Authentification flog;
        Form_accueil fmenu;

        public void initialiser()
        {
            nom = "Groupe4";
            pass = "DL2025";
        }
        public bool verifierConnexion(string u, string p)
        {
            if ((nom.ToString() == nom.ToString()) && (pass.ToString() == p.ToString()))
            {
                return true;
            }
            else
            {
                return false;
            }

        }
        public void afficheFormLoging()
        {
            flog = new Form_Authentification();
            flog.ShowDialog();
        }
        public void afficheFormAccueil()
        {
            fmenu = new Form_accueil();
            fmenu.Show();
        }
    }
}
