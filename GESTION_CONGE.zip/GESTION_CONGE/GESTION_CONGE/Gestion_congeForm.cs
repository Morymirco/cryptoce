﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GESTION_CONGE
{
    public partial class FormEmployer : Form
    {
        public Form_accueil ParentForm_accueil { get; set; }
        public FormEmployer(Form_accueil parent)
        {
            InitializeComponent();
            ParentForm_accueil = parent; // Associer le parent
        }

        public FormEmployer()
        {
            // TODO: Complete member initialization
        }

        private void btn_enregistrer_Click(object sender, EventArgs e)
        {
            if (txt_nom.Text == "")
            {
                label_erreur_nom.Visible = true;
                txt_nom.Focus();
            }
            else if (txt_prenom.Text == "")
            {
                label_erreur_prenom.Visible = true;
                txt_prenom.Focus();
            }
            else if (txt_anciennete.Text == "")
            {
                label_erreur_ancienneté.Visible = true;
                txt_anciennete.Focus();
            }
            else if (txt_date_Nais.Text == "")
            {
                label_erreur_date.Visible = true;
                txt_date_Nais.Focus();
            }
            else if (combo_statut.Text == "choisir")
            {
                label_erreur_statut.Visible = true;
                combo_statut.Focus();
            }
            else if (txt_telephone.Text == "")
            {
                label_erreur_tel.Visible = true;
                txt_telephone.Focus();
            }
            else
            {
 
            }

            try
            {
                Employer employer = new Employer
                {
                    Nom = txt_nom.Text.Trim(),
                    Prenom = txt_prenom.Text.Trim(),
                    Anciennete = int.Parse(txt_anciennete.Text),
                    DateNaissance = DateTime.Parse(txt_date_Nais.Text),
                    Statut = combo_statut.SelectedItem.ToString(),
                    Telephone = txt_telephone.Text.Trim()
                };

                int age = DateTime.Now.Year - employer.DateNaissance.Year;
                if (DateTime.Now < employer.DateNaissance.AddYears(age))
                {
                    age--; // Ajustement si l'anniversaire n'est pas encore passé cette année
                }

                // Maintenant, on envoie l'âge à la base de données
                EmployerService service = new EmployerService();
                bool success = service.AjouterEmployer(employer, age);

                if (success)
                    MessageBox.Show("Employé ajouté avec succès !");
                else
                    MessageBox.Show("Erreur lors de l'ajout de l'employé.");


            }
            catch (Exception ex) {
                MessageBox.Show("Erreur : " + ex);
            }

           


        }

        private void FormEmployer_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
