﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace GESTION_CONGE
{

    public class Employer
    {
        public int Id { get; set; }
        public string Nom { get; set; }
        public string Prenom { get; set; }
        public int Anciennete { get; set; }
        public DateTime DateNaissance { get; set; }
        public string Statut { get; set; }
        public string Telephone { get; set; }
    }

    class EmployerService
    {
        private string connectionString = "Data Source=(local);Initial Catalog=GESTION_CONGER;Persist Security Info=True;User ID='gestion conges';Password='12345'";
        


        // Méthode pour ajouter un employé
        public bool AjouterEmployer(Employer employer, int age)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "INSERT INTO EMPLOYER (NOM_EMPLOYER, PRENOM_EMPLOYER, ANCIENNETE, AGE, STATUT, TELEPHONE) " +
               "VALUES (@Nom, @Prenom, @Anciennete, @Age, @Statut, @Telephone)";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Nom", employer.Nom);
                        cmd.Parameters.AddWithValue("@Prenom", employer.Prenom);
                        cmd.Parameters.AddWithValue("@Anciennete", employer.Anciennete);
                        cmd.Parameters.AddWithValue("@Age", age); // Âge calculé
                        cmd.Parameters.AddWithValue("@Statut", employer.Statut);
                        cmd.Parameters.AddWithValue("@Telephone", employer.Telephone);

                        int rowsAffected = cmd.ExecuteNonQuery();
                        return rowsAffected > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur : " + ex.Message);
                return false;
            }
        }
    
    }
}
