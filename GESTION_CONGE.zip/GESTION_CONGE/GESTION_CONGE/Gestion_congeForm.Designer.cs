﻿namespace GESTION_CONGE
{
    partial class FormEmployer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_enregistrer = new System.Windows.Forms.Button();
            this.combo_statut = new System.Windows.Forms.ComboBox();
            this.txt_anciennete = new System.Windows.Forms.TextBox();
            this.txt_prenom = new System.Windows.Forms.TextBox();
            this.txt_nom = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label_erreur_nom = new System.Windows.Forms.Label();
            this.label_erreur_prenom = new System.Windows.Forms.Label();
            this.label_erreur_ancienneté = new System.Windows.Forms.Label();
            this.label_erreur_date = new System.Windows.Forms.Label();
            this.label_erreur_statut = new System.Windows.Forms.Label();
            this.label_erreur_tel = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_telephone = new System.Windows.Forms.TextBox();
            this.txt_date_Nais = new System.Windows.Forms.DateTimePicker();
            this.button2 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(-1, -5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(817, 46);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(189, 7);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(438, 23);
            this.label1.TabIndex = 1;
            this.label1.Text = "GESTIONS DE CONGES DES EMPLOYERS";
            // 
            // btn_enregistrer
            // 
            this.btn_enregistrer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btn_enregistrer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_enregistrer.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_enregistrer.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_enregistrer.Location = new System.Drawing.Point(504, 274);
            this.btn_enregistrer.Name = "btn_enregistrer";
            this.btn_enregistrer.Size = new System.Drawing.Size(155, 39);
            this.btn_enregistrer.TabIndex = 26;
            this.btn_enregistrer.Text = "Enregistrer";
            this.btn_enregistrer.UseVisualStyleBackColor = false;
            this.btn_enregistrer.Click += new System.EventHandler(this.btn_enregistrer_Click);
            // 
            // combo_statut
            // 
            this.combo_statut.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.combo_statut.FormattingEnabled = true;
            this.combo_statut.Items.AddRange(new object[] {
            "Cadre",
            "Employer"});
            this.combo_statut.Location = new System.Drawing.Point(504, 126);
            this.combo_statut.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.combo_statut.Name = "combo_statut";
            this.combo_statut.Size = new System.Drawing.Size(147, 27);
            this.combo_statut.TabIndex = 24;
            this.combo_statut.Text = "choisir";
            // 
            // txt_anciennete
            // 
            this.txt_anciennete.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_anciennete.Location = new System.Drawing.Point(137, 189);
            this.txt_anciennete.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txt_anciennete.Name = "txt_anciennete";
            this.txt_anciennete.Size = new System.Drawing.Size(147, 26);
            this.txt_anciennete.TabIndex = 22;
            // 
            // txt_prenom
            // 
            this.txt_prenom.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_prenom.Location = new System.Drawing.Point(137, 118);
            this.txt_prenom.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txt_prenom.Name = "txt_prenom";
            this.txt_prenom.Size = new System.Drawing.Size(147, 26);
            this.txt_prenom.TabIndex = 21;
            // 
            // txt_nom
            // 
            this.txt_nom.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_nom.Location = new System.Drawing.Point(137, 52);
            this.txt_nom.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txt_nom.Name = "txt_nom";
            this.txt_nom.Size = new System.Drawing.Size(147, 26);
            this.txt_nom.TabIndex = 20;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label6.Location = new System.Drawing.Point(343, 124);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 20);
            this.label6.TabIndex = 18;
            this.label6.Text = "Statut";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label5.Location = new System.Drawing.Point(343, 55);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(143, 18);
            this.label5.TabIndex = 17;
            this.label5.Text = "Date Naissance";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label4.Location = new System.Drawing.Point(13, 193);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(106, 18);
            this.label4.TabIndex = 16;
            this.label4.Text = "Ancienneté";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label3.Location = new System.Drawing.Point(13, 125);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 18);
            this.label3.TabIndex = 15;
            this.label3.Text = "Prenom";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.Control;
            this.label2.Location = new System.Drawing.Point(13, 57);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 18);
            this.label2.TabIndex = 14;
            this.label2.Text = "Nom";
            // 
            // label_erreur_nom
            // 
            this.label_erreur_nom.AutoSize = true;
            this.label_erreur_nom.Font = new System.Drawing.Font("Microsoft YaHei UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_erreur_nom.ForeColor = System.Drawing.Color.Red;
            this.label_erreur_nom.Location = new System.Drawing.Point(302, 52);
            this.label_erreur_nom.Name = "label_erreur_nom";
            this.label_erreur_nom.Size = new System.Drawing.Size(21, 26);
            this.label_erreur_nom.TabIndex = 29;
            this.label_erreur_nom.Text = "*";
            this.label_erreur_nom.Visible = false;
            // 
            // label_erreur_prenom
            // 
            this.label_erreur_prenom.AutoSize = true;
            this.label_erreur_prenom.Font = new System.Drawing.Font("Microsoft YaHei UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_erreur_prenom.ForeColor = System.Drawing.Color.Red;
            this.label_erreur_prenom.Location = new System.Drawing.Point(302, 122);
            this.label_erreur_prenom.Name = "label_erreur_prenom";
            this.label_erreur_prenom.Size = new System.Drawing.Size(21, 26);
            this.label_erreur_prenom.TabIndex = 30;
            this.label_erreur_prenom.Text = "*";
            this.label_erreur_prenom.Visible = false;
            // 
            // label_erreur_ancienneté
            // 
            this.label_erreur_ancienneté.AutoSize = true;
            this.label_erreur_ancienneté.Font = new System.Drawing.Font("Microsoft YaHei UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_erreur_ancienneté.ForeColor = System.Drawing.Color.Red;
            this.label_erreur_ancienneté.Location = new System.Drawing.Point(302, 189);
            this.label_erreur_ancienneté.Name = "label_erreur_ancienneté";
            this.label_erreur_ancienneté.Size = new System.Drawing.Size(21, 26);
            this.label_erreur_ancienneté.TabIndex = 31;
            this.label_erreur_ancienneté.Text = "*";
            this.label_erreur_ancienneté.Visible = false;
            // 
            // label_erreur_date
            // 
            this.label_erreur_date.AutoSize = true;
            this.label_erreur_date.Font = new System.Drawing.Font("Microsoft YaHei UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_erreur_date.ForeColor = System.Drawing.Color.Red;
            this.label_erreur_date.Location = new System.Drawing.Point(669, 58);
            this.label_erreur_date.Name = "label_erreur_date";
            this.label_erreur_date.Size = new System.Drawing.Size(21, 26);
            this.label_erreur_date.TabIndex = 32;
            this.label_erreur_date.Text = "*";
            this.label_erreur_date.Visible = false;
            // 
            // label_erreur_statut
            // 
            this.label_erreur_statut.AutoSize = true;
            this.label_erreur_statut.Font = new System.Drawing.Font("Microsoft YaHei UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_erreur_statut.ForeColor = System.Drawing.Color.Red;
            this.label_erreur_statut.Location = new System.Drawing.Point(669, 130);
            this.label_erreur_statut.Name = "label_erreur_statut";
            this.label_erreur_statut.Size = new System.Drawing.Size(21, 26);
            this.label_erreur_statut.TabIndex = 33;
            this.label_erreur_statut.Text = "*";
            this.label_erreur_statut.Visible = false;
            // 
            // label_erreur_tel
            // 
            this.label_erreur_tel.AutoSize = true;
            this.label_erreur_tel.Font = new System.Drawing.Font("Microsoft YaHei UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_erreur_tel.ForeColor = System.Drawing.Color.Red;
            this.label_erreur_tel.Location = new System.Drawing.Point(669, 187);
            this.label_erreur_tel.Name = "label_erreur_tel";
            this.label_erreur_tel.Size = new System.Drawing.Size(21, 26);
            this.label_erreur_tel.TabIndex = 34;
            this.label_erreur_tel.Text = "*";
            this.label_erreur_tel.Visible = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label7.Location = new System.Drawing.Point(344, 193);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(101, 18);
            this.label7.TabIndex = 19;
            this.label7.Text = "Telephone";
            // 
            // txt_telephone
            // 
            this.txt_telephone.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_telephone.Location = new System.Drawing.Point(504, 193);
            this.txt_telephone.Name = "txt_telephone";
            this.txt_telephone.Size = new System.Drawing.Size(147, 26);
            this.txt_telephone.TabIndex = 25;
            // 
            // txt_date_Nais
            // 
            this.txt_date_Nais.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_date_Nais.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.txt_date_Nais.Location = new System.Drawing.Point(504, 55);
            this.txt_date_Nais.Name = "txt_date_Nais";
            this.txt_date_Nais.Size = new System.Drawing.Size(147, 26);
            this.txt_date_Nais.TabIndex = 35;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Teal;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.Black;
            this.button2.Location = new System.Drawing.Point(662, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(38, 43);
            this.button2.TabIndex = 36;
            this.button2.Text = "X";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // FormEmployer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Teal;
            this.ClientSize = new System.Drawing.Size(694, 346);
            this.Controls.Add(this.txt_date_Nais);
            this.Controls.Add(this.label_erreur_tel);
            this.Controls.Add(this.label_erreur_statut);
            this.Controls.Add(this.label_erreur_date);
            this.Controls.Add(this.label_erreur_ancienneté);
            this.Controls.Add(this.label_erreur_prenom);
            this.Controls.Add(this.label_erreur_nom);
            this.Controls.Add(this.btn_enregistrer);
            this.Controls.Add(this.txt_telephone);
            this.Controls.Add(this.combo_statut);
            this.Controls.Add(this.txt_anciennete);
            this.Controls.Add(this.txt_prenom);
            this.Controls.Add(this.txt_nom);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormEmployer";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Gestion_congeForm";
            this.Load += new System.EventHandler(this.FormEmployer_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_enregistrer;
        private System.Windows.Forms.ComboBox combo_statut;
        private System.Windows.Forms.TextBox txt_anciennete;
        private System.Windows.Forms.TextBox txt_prenom;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label_erreur_nom;
        private System.Windows.Forms.Label label_erreur_prenom;
        private System.Windows.Forms.Label label_erreur_ancienneté;
        private System.Windows.Forms.Label label_erreur_date;
        private System.Windows.Forms.Label label_erreur_statut;
        private System.Windows.Forms.Label label_erreur_tel;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_telephone;
        protected System.Windows.Forms.TextBox txt_nom;
        private System.Windows.Forms.DateTimePicker txt_date_Nais;
        private System.Windows.Forms.Button button2;
    }
}