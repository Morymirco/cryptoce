﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GESTION_CONGE
{
    public partial class Form_Authentification : Form
    {
        public Form_Authentification()
        {
            InitializeComponent();
        }
        Auth auth = new Auth();
        private void Authentification_Load(object sender, EventArgs e)
        {
            auth.initialiser();
        }

        private void btn_connexion_Click(object sender, EventArgs e)
        {
            string n, m;
            n = txt_login.Text;
            m = txt_password.Text;
            if (auth.verifierConnexion(n, m) == true)
            {
                auth.afficheFormAccueil();
                this.Hide();

            }
            else
            {
                MessageBox.Show("verifier vos information d'authentification d'authentification", "Authentification", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txt_login.Focus();
            }
        }

        private void btn_quitter_Click(object sender, EventArgs e)
        {

            DialogResult r = MessageBox.Show("voulez-vous quitter l'application", "Fenetre", MessageBoxButtons.YesNo, MessageBoxIcon.None);
            switch (r)
            {
                case DialogResult.Yes:
                    Environment.Exit(0);
                    break;
                case DialogResult.No:
                    MessageBox.Show("Annulation de l'arret", "Fenetre", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    break;
            }
        }
    }
}
